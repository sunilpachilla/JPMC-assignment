package com.sunil.library.library.service;

import java.util.List;

import com.sunil.library.library.uiModel.Book;

public interface BookService {
	
	public List<Book> findBooks();
	
	public Book findById(int id);
	
	public void save(Book book);
	

}
