package com.sunil.library.library.service;

import java.util.List;

import com.sunil.library.library.uiModel.Course;

public interface CourseService {
	
	public void save(Course course);
	
	

	public List<Course> getCourses();
}
