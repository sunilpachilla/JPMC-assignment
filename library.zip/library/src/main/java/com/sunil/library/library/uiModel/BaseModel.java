package com.sunil.library.library.uiModel;

import java.io.Serializable;

public abstract class BaseModel implements Serializable{

}
